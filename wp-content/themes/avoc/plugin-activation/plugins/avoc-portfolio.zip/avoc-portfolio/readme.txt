*** AVOC Portfolio (custom post type) ***


August 20 2015 - Version 1.0
	
	* First Release

